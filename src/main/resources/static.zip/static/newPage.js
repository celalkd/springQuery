function newPage() {
    window.location.href = "index_1.html";   
}

function newPage_1() {
    window.location.href = "index.html";   
}